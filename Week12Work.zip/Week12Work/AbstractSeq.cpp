//
// Created by Alvaro Espinoza on 2020-05-13.
//
#include "AbstractSeq.h"
#include <iostream>
void AbstractSeq::printSeq(int x, int y) {

    if(x < y){
        for(int i = x; i < y ;i++){
            std::cout<< fun(i)<<" ";
        }
        std::cout<<std::endl;
    }
}

int AbstractSeq::sumSeq(int x,int y){
    int sum ;
    if(x < y){
        for(int i = x; i < y ;i++){
           sum += fun(i);
        }
        std::cout<<std::endl;
    }
    return sum;
}
