//
// Created by Alvaro Espinoza on 2020-05-13.
//

#ifndef WEEK12WORK_ABSTRACTSEQ_H
#define WEEK12WORK_ABSTRACTSEQ_H


class AbstractSeq {

    public:
            virtual int fun(int)=0;
            void printSeq(int x,int y);
            int sumSeq(int x,int y);

};


#endif //WEEK12WORK_ABSTRACTSEQ_H
