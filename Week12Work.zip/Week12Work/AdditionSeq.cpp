//
// Created by Alvaro Espinoza on 2020-05-13.
//
#include "AdditionSeq.h"
int AdditionSeq::fun(int x) {
    x += x+150;
    return x;
}

