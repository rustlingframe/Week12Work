//
// Created by Alvaro Espinoza on 2020-05-12.
//

#ifndef WEEK12WORK_ABSTRACTSORT_H
#define WEEK12WORK_ABSTRACTSORT_H


class AbstractSort {

    private:
        int comparisons = 0 ;
    public:
        virtual void sort(int*,int) = 0;
        int compare(int x, int y);
        int getComparisons();
};


#endif //WEEK12WORK_ABSTRACTSORT_H
