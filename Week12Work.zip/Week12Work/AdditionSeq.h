//
// Created by Alvaro Espinoza on 2020-05-13.
//

#ifndef WEEK12WORK_ADDITIONSEQ_H
#define WEEK12WORK_ADDITIONSEQ_H

#include "AbstractSeq.h"

class AdditionSeq : public AbstractSeq{
    public:
        virtual int fun(int);

};


#endif //WEEK12WORK_ADDITIONSEQ_H
