//
// Created by Alvaro Espinoza on 2020-05-13.
//

#include "MultiplySeq.h"

int MultiplySeq::fun(int x) {
    x *= x;
    return x;
}