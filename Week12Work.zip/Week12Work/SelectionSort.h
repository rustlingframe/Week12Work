//
// Created by Alvaro Espinoza on 2020-05-12.
//


#ifndef WEEK12WORK_SELECTIONSORT_H
#define WEEK12WORK_SELECTIONSORT_H
#include "AbstractSort.h"

class SelectionSort : public AbstractSort {

    public:
        virtual void sort(int*,int);

};


#endif //WEEK12WORK_SELECTIONSORT_H
