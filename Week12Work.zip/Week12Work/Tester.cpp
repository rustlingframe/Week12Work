//
// Created by Alvaro Espinoza on 2020-05-13.
//
#include <iostream>
#include "AdditionSeq.cpp"
#include "AbstractSeq.cpp"


int main(){

    AdditionSeq additionSeq;

    additionSeq.printSeq(1,5);
}

