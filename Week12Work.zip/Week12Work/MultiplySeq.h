//
// Created by Alvaro Espinoza on 2020-05-13.
//

#ifndef WEEK12WORK_MULTIPLYSEQ_H
#define WEEK12WORK_MULTIPLYSEQ_H

#include "AbstractSeq.h"

class MultiplySeq : public AbstractSeq{

        public:
            int fun(int);

};


#endif //WEEK12WORK_MULTIPLYSEQ_H
