//
// Created by Alvaro Espinoza on 2020-05-12.
//

#include "SelectionSort.h"

#include <iostream>

void SelectionSort::sort(int *array, int size) {
    for(int i = 0; i < size;i++){

        for(int j = 0; j < size;j++){

            if(AbstractSort::compare(*(array+i),*(array+j))== 1){
                int temp = *(array+i);
                *(array+i) = *(array+j);
                *(array+j) = temp;
            }
        }
    }

    std::cout<<"Number of comparisons made during this sort: "<<getComparisons()<<std::endl;
}


int main ()
{
    SelectionSort selectionSort;
    int array[10] = {2,5,9,23,16,3,7,4,6,7};

    for(int i = 0; i < 10 ;i++){
        std::cout<<array[i]<<" ";
    }
    std::cout<<std::endl;

    selectionSort.sort(array,10);

    for(int i = 0; i < 10 ;i++){
        std::cout<<array[i]<<" ";
    }



}
