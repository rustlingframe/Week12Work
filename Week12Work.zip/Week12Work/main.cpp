#include <iostream>

class First{
    protected:
        int a;
    public:
        First(int x =2){
            a = x;
        }

        int getVar(){
            return a;
        }

};

class Second: public First{
    private:
    int b;
    public:
        Second(int y = 100){
            b = y;
            }
        int getVar(){
         return b;
        }


};


int main() {
    First *object1;
    Second object2;

    object1 = &object2;
    std::cout<<object1->getVar()<<std::endl;


}