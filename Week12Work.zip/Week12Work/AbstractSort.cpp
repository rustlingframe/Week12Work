//
// Created by Alvaro Espinoza on 2020-05-12.
//

#include "AbstractSort.h"

int AbstractSort ::compare(int x, int y)
{
    ++comparisons;
    if (x<y){
        return 1;
    }
    else if (x>y){
        return -1;
    }

    else {
        return 0;
    }
}
int AbstractSort ::getComparisons() { return comparisons;}